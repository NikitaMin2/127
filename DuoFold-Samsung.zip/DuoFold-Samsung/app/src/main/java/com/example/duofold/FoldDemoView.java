package com.example.duofold;

import android.content.Context;
import android.graphics.*;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.view.MotionEvent;
import android.view.View;

public class FoldDemoView extends View implements SensorEventListener {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final SensorManager sm;
    private final Sensor hinge;
    private float angle = 180f, target = 180f;
    private float downX;
    private long last;
    private boolean sensorWorking;

    public FoldDemoView(Context c) {
        super(c); setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        sm = (SensorManager)c.getSystemService(Context.SENSOR_SERVICE);
        Sensor h = null;
        if (Build.VERSION.SDK_INT >= 30) h = sm.getDefaultSensor(Sensor.TYPE_HINGE_ANGLE);
        hinge = h;
        if (hinge != null) { sensorWorking = sm.registerListener(this, hinge, SensorManager.SENSOR_DELAY_GAME); }
        last = System.nanoTime();
        setFocusable(true);
    }

    @Override protected void onDetachedFromWindow() { sm.unregisterListener(this); super.onDetachedFromWindow(); }

    @Override public void onSensorChanged(SensorEvent e) {
        if (hinge != null && e.sensor.getType() == Sensor.TYPE_HINGE_ANGLE && e.values.length > 0) {
            target = Math.max(0f, Math.min(180f, e.values[0]));
            invalidate();
        }
    }
    @Override public void onAccuracyChanged(Sensor s, int a) {}

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (e.getActionMasked() == MotionEvent.ACTION_DOWN) { downX = e.getX(); return true; }
        if (e.getActionMasked() == MotionEvent.ACTION_MOVE && !sensorWorking) {
            float dx = e.getX() - downX;
            target = Math.max(0f, Math.min(180f, 180f - dx * 0.45f));
            invalidate(); return true;
        }
        if (e.getActionMasked() == MotionEvent.ACTION_UP && !sensorWorking) {
            target = (target > 90f ? 0f : 180f); invalidate(); return true;
        }
        return true;
    }

    private float eased(float x) { x=Math.max(0,Math.min(1,x)); return x*x*(3-2*x); }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        long now=System.nanoTime(); float dt=(now-last)/1e9f; last=now;
        float k=Math.min(1f, dt*10f); angle += (target-angle)*k;
        drawScene(c, angle);
        if (Math.abs(target-angle)>0.2f) postInvalidateOnAnimation();
    }

    private void drawScene(Canvas c, float a) {
        int w=getWidth(), h=getHeight();
        p.setStyle(Paint.Style.FILL); p.setShader(null); p.setColor(Color.rgb(8,8,10)); c.drawRect(0,0,w,h,p);
        float t=eased(a/180f);
        float mid=w/2f;
        float perspective=0.16f + 0.84f*t;
        float panelW=mid*perspective;
        float leftL=mid-panelW, rightR=mid+panelW;

        // Frosted, photographic-looking abstract UI cards: this is deliberately local to the demo.
        drawPanel(c,leftL,0,mid,h,true,t);
        drawPanel(c,mid,0,rightR,h,false,t);

        // Hinge highlight/shadow, strongest while partially folded.
        float foldStrength=1f-Math.abs(2*t-1f);
        p.setShader(new LinearGradient(mid-55,0,mid+55,0,
                new int[]{0x00101014,0x55202028,0xAA000000,0x55202028,0x00101014},null,Shader.TileMode.CLAMP));
        c.drawRect(mid-55,0,mid+55,h,p); p.setShader(null);
        p.setColor(Color.argb((int)(35+75*foldStrength),255,255,255)); c.drawRect(mid-1,0,mid+1,h,p);

        p.setTypeface(Typeface.create("sans",Typeface.BOLD)); p.setTextSize(18); p.setColor(0xBFFFFFFF);
        String s = sensorWorking ? "DUOFOLD • hinge sensor" : "DUOFOLD • demo mode";
        c.drawText(s,24,32,p);
        p.setTypeface(Typeface.DEFAULT); p.setTextSize(13); p.setColor(0x88FFFFFF);
        c.drawText(sensorWorking ? "Fold/unfold the phone" : "Drag horizontally to fold • tap to snap",24,53,p);
    }

    private void drawPanel(Canvas c,float l,float top,float r,float bottom,boolean left,float t) {
        float alpha=0.88f;
        p.setShader(new LinearGradient(0,top,0,bottom,0xFF171820,0xFF07080C,Shader.TileMode.CLAMP));
        c.drawRect(l,top,r,bottom,p); p.setShader(null);
        // Fake translucent app tiles to show the glass/reprojection character.
        float pad=22, x=l+pad, y=85, ww=Math.max(10,r-l-pad*2), hh=92;
        round(c,x,y,x+ww,y+hh,28,0xB82A2B33);
        round(c,x,y+hh+16,x+ww*0.48f,y+hh+120,24,0xA81D1F27);
        round(c,x+ww*0.52f,y+hh+16,x+ww,y+hh+120,24,0xA81D1F27);
        p.setColor(0xDFFFFFFF); p.setTextSize(22); p.setTypeface(Typeface.DEFAULT_BOLD);
        c.drawText(left?"Home":"Apps",x+18,y+34,p);
        p.setTextSize(13); p.setColor(0x99FFFFFF); c.drawText(left?"Your screen, behind the glass":"Continue on the other panel",x+18,y+59,p);
        p.setColor(0xDFFFFFFF); p.setTextSize(28); c.drawText(left?"◉":"✦",x+18,y+hh+57,p);
        p.setTextSize(12); p.setColor(0x99FFFFFF); c.drawText(left?"Messages":"Gallery",x+58,y+hh+51,p);
        p.setColor(0xDFFFFFFF); p.setTextSize(28); c.drawText(left?"⌁":"◌",x+ww*0.52f+18,y+hh+57,p);
        p.setTextSize(12); p.setColor(0x99FFFFFF); c.drawText(left?"Music":"Notes",x+ww*0.52f+58,y+hh+51,p);
    }
    private void round(Canvas c,float l,float t,float r,float b,float rad,int color){p.setColor(color);p.setShader(null);c.drawRoundRect(l,t,r,b,rad,rad,p);}
}
