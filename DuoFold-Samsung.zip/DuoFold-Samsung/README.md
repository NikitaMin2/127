# DuoFold — Samsung Fold prototype

This project is a buildable Android prototype for the iPhone-Duo-style folding visual.

## Build

1. Create an empty GitHub repository.
2. Upload this project (including `.github/workflows/build.yml`).
3. Open **Actions → Build DuoFold APK → Run workflow**.
4. Download the **DuoFold-apk** artifact and install `app-debug.apk` on the Fold7.

## Important

This is a visual prototype, not a Samsung SystemUI replacement. Samsung restricts the continuous hinge-angle sensor/API for ordinary third-party apps on physical Fold devices. If the hinge sensor is exposed, the demo follows it automatically; otherwise drag horizontally or tap to test the animation.

The next step toward the original Reddit POC is a privileged/system-level or approved Good Lock integration so the effect can operate over real system/app content during a physical fold transition.
